public class Farmer {

    private int farmerId;
    private String farmerName;
    private String cropName;
    private double landArea;

    public Farmer(int farmerId, String farmerName,
                  String cropName, double landArea) {

        this.farmerId = farmerId;
        this.farmerName = farmerName;
        this.cropName = cropName;
        this.landArea = landArea;
    }

    public int getFarmerId() {
        return farmerId;
    }

    @Override
    public String toString() {

        return "Farmer ID : " + farmerId +
               "\nFarmer Name : " + farmerName +
               "\nCrop Name : " + cropName +
               "\nLand Area : " + landArea + " Acres" +
               "\n---------------------------";
    }
}