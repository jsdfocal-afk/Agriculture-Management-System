import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class AgricultureManagement {

    static ArrayList<Farmer> farmers = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        while (true) {

            System.out.println("\n===== AGRICULTURE MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Farmer");
            System.out.println("2. View Farmers");
            System.out.println("3. Search Farmer");
            System.out.println("4. Delete Farmer");
            System.out.println("5. Save Records");
            System.out.println("6. Exit");

            System.out.print("Enter Choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    addFarmer();
                    break;

                case 2:
                    viewFarmers();
                    break;

                case 3:
                    searchFarmer();
                    break;

                case 4:
                    deleteFarmer();
                    break;

                case 5:
                    saveRecords();
                    break;

                case 6:
                    System.out.println("Thank You!");
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice!");
            }
        }
    }

    static void addFarmer() {

        System.out.print("Enter Farmer ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Farmer Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Crop Name: ");
        String crop = sc.nextLine();

        System.out.print("Enter Land Area (Acres): ");
        double area = sc.nextDouble();

        farmers.add(new Farmer(id, name, crop, area));

        System.out.println("Farmer Added Successfully!");
    }

    static void viewFarmers() {

        if (farmers.isEmpty()) {
            System.out.println("No Farmers Found!");
            return;
        }

        for (Farmer farmer : farmers) {
            System.out.println(farmer);
        }
    }

    static void searchFarmer() {

        System.out.print("Enter Farmer ID: ");
        int id = sc.nextInt();

        for (Farmer farmer : farmers) {

            if (farmer.getFarmerId() == id) {
                System.out.println(farmer);
                return;
            }
        }

        System.out.println("Farmer Not Found!");
    }

    static void deleteFarmer() {

        System.out.print("Enter Farmer ID: ");
        int id = sc.nextInt();

        for (int i = 0; i < farmers.size(); i++) {

            if (farmers.get(i).getFarmerId() == id) {

                farmers.remove(i);

                System.out.println("Farmer Deleted Successfully!");
                return;
            }
        }

        System.out.println("Farmer Not Found!");
    }

    static void saveRecords() {

        try {

            FileWriter fw = new FileWriter("farmers.txt");

            for (Farmer farmer : farmers) {

                fw.write(farmer.toString());
                fw.write("\n");
            }

            fw.close();

            System.out.println("Records Saved Successfully!");

        } catch (Exception e) {

            System.out.println("Error Saving File!");
        }
    }
}